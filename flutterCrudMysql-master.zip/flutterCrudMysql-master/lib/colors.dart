import 'package:flutter/material.dart';

const CePink50 = const Color(0xFFFEEAE6);
const CePink100 = const Color(0xFFFEDBD0);
const CePink300 = const Color(0xFFFBB8AC);

const CeBrown900 = const Color(0xFFA1887F);/*0xFF442B1D*/

const CeErrorRed = const Color(0xFFA1887F);

const CeSurfaceWhite = const Color(0xFFFFFBFA);
const CeBackgroundWhite = Colors.lightBlueAccent;